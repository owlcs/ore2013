# ORE reasoner competition 2013 results


## OVERVIEW OF THE SPREADSHEETS:

Betting-live-competition
Results of the live competition betting.

Results-live-competition
Results of the live competition, classification in EL and DL only.

Results-offline-competition
Detailed results of the offline competition, including fails and timeouts.

Results-user-submitted
Results of the classification challenge on the user submitted ontologies.


## PLEASE NOTE:

The spreadsheets are locked to prevent accidental changes. You can unlock them in Excel on the "Review" tab. There is no password.